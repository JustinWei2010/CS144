**********************************************************
TEAM: Amazon Meets Facebook
**********************************************************

Justin Wei: mysql batch script
Samping Chuang: SHA-1 hashing
